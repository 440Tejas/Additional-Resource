package com.example.intent1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView messageTextView = findViewById(R.id.message_text_view);

        // Retrieve the message from the Intent
        Intent intent = getIntent();
        String message = intent.getStringExtra("message");

        // Display the message in the TextView
        if (message != null) {
            messageTextView.setText(message);
        }else{
            messageTextView.setText("null value");
        }
    }
}
